package com.stagepads.app

import android.app.*
import android.os.*
import android.content.*
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.media.*
import android.media.midi.*
import android.net.Uri
import android.view.*
import android.widget.*
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.*

class MainActivity : Activity() {
 private val prefs by lazy { getSharedPreferences("stagepads", MODE_PRIVATE) }
 private lateinit var root: LinearLayout
 private val handler = Handler(Looper.getMainLooper())
 private val names = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B") + (1..8).map { "DRUM $it" }
 private val players = ConcurrentHashMap<Int, MediaPlayer>()
 private val effects = ConcurrentHashMap<Int, android.media.audiofx.Equalizer>()
 private val buttons = mutableMapOf<Int, Button>()
 private val uris = mutableMapOf<Int, Uri>()
 private val routes = mutableMapOf<Int, String>()
 private val midiNotes = mutableMapOf<Int, Int>()
 private var pendingImport = -1
 private var midiLearn = -1
 private var bpm = 120
 private var clickSound = true
 private var running = false
 private var beat = 0
 private var lastTap = 0L
 private val taps = mutableListOf<Long>()
 private var clickRoute = "R"
 private var fadeMs = 500
 private var cutoff = 100
 private var clickTrack: AudioTrack? = null
 private var midiManager: MidiManager? = null
 private val midiDevices = mutableListOf<MidiDevice>()
 private val outputPorts = mutableListOf<MidiOutputPort>()
 private lateinit var led: TextView
 private lateinit var bpmText: TextView
 private var page = 0
 private val pianoVoices = mutableMapOf<Int, AudioTrack>()
 private val pianoBaseNote = 60
 private val background = Color.rgb(15,19,29)
 private val accent = Color.rgb(52,204,183)

 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=background; window.navigationBarColor=background
  bpm=prefs.getInt("bpm",120); fadeMs=prefs.getInt("fade",500); cutoff=prefs.getInt("cutoff",100); clickRoute=prefs.getString("clickRoute","R")!!
  clickSound=prefs.getBoolean("clickSound",true)
  names.indices.forEach { i -> prefs.getString("uri$i",null)?.let { uris[i]=Uri.parse(it) }; routes[i]=prefs.getString("route$i","L")!!; val n=prefs.getInt("midi$i",-1); if(n>=0) midiNotes[i]=n }
  setupMidi(); showPads()
 }
 private fun text(s:String, size:Float=16f): TextView = TextView(this).apply { text=s; textSize=size; setTextColor(Color.WHITE); setPadding(12,12,12,12) }
 private fun button(s:String, onClick:()->Unit):Button = Button(this).apply { text=s; isAllCaps=false; setOnClickListener { onClick() } }
 private fun column():LinearLayout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(12,8,12,8) }
 private fun row():LinearLayout=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
 private fun addWeight(r:LinearLayout,v:View){r.addView(v,LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f))}
 private fun section(s:String){root.addView(text(s,19f))}
 private fun setup(title:String){root=column();root.setBackgroundColor(background);val outer=column();outer.setBackgroundColor(background)
  val nav=row();addWeight(nav,button("🎹 PADS"){showPads()});addWeight(nav,button("📝 NOTES"){showNotes()});addWeight(nav,button("🎹 PIANO"){showPiano()});outer.addView(nav)
  val scroll=ScrollView(this);scroll.fillViewport=true;scroll.addView(root);outer.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(outer)
  root.addView(text(title,25f))
 }
 private fun showPads(){page=0;buttons.clear();setup("STAGEPADS • LIVE")
  section("CLICK / METRÔNOMO")
  led=text("●",32f);led.setTextColor(Color.DKGRAY);bpmText=text("$bpm BPM",22f)
  val tempo=row();addWeight(tempo,led);addWeight(tempo,bpmText);addWeight(tempo,button("TAP"){val now=SystemClock.elapsedRealtime();if(now-lastTap>2000)taps.clear();if(lastTap>0 && now-lastTap<=2000)taps.add(now-lastTap);lastTap=now;if(taps.size>6)taps.removeAt(0);if(taps.isNotEmpty())setBpm((60000.0/taps.average()).roundToInt())});root.addView(tempo)
  val ctr=row();addWeight(ctr,button("−"){setBpm(bpm-1)});addWeight(ctr,button("+ "){setBpm(bpm+1)});addWeight(ctr,button("DIGITAR BPM"){val input=EditText(this);input.inputType=2;input.setText("$bpm");AlertDialog.Builder(this).setTitle("BPM (30–300)").setView(input).setPositiveButton("OK"){_,_->setBpm(input.text.toString().toIntOrNull()?:bpm)}.setNegativeButton("Cancelar",null).show()});root.addView(ctr)
  val click=row();addWeight(click,button(if(running)"■ PARAR":"▶ INICIAR"){running=!running;if(running)tick() else led.setTextColor(Color.DKGRAY);showPads()});addWeight(click,button(if(clickSound)"🔊 CLICK ON":"🔇 CLICK OFF"){clickSound=!clickSound;prefs.edit().putBoolean("clickSound",clickSound).apply();showPads()});addWeight(click,button("CLICK: $clickRoute"){clickRoute=nextRoute(clickRoute);prefs.edit().putString("clickRoute",clickRoute).apply();showPads()});root.addView(click)
  section("12 TONS • clique para tocar / segure para configurar")
  for (start in 0 until 12 step 3) {val r=row();for(i in start until start+3){val b=button(names[i]+if(uris.containsKey(i))" ●" else " +"){togglePad(i)};b.setOnLongClickListener { configure(i);true };buttons[i]=b;addWeight(r,b)};root.addView(r)}
  section("CONTROLES DOS PADS")
  root.addView(text("Cutoff (redução das frequências altas) • $cutoff%"));root.addView(SeekBar(this).apply { max=100;progress=cutoff;setOnSeekBarChangeListener(seek({cutoff=it;prefs.edit().putInt("cutoff",it).apply();applyCutoff()})) })
  root.addView(text("Crossfade / fade de entrada e saída • ${fadeMs}ms"));root.addView(SeekBar(this).apply {max=5000;progress=fadeMs;setOnSeekBarChangeListener(seek({fadeMs=it;prefs.edit().putInt("fade",it).apply()}))})
  section("8 DRUM PADS")
  for(start in 12 until 20 step 4){val r=row();for(i in start until start+4){val b=button(names[i]+if(uris.containsKey(i))" ●" else " +"){togglePad(i)};b.setOnLongClickListener{configure(i);true};buttons[i]=b;addWeight(r,b)};root.addView(r)}
  root.addView(text("Dica: segure qualquer pad para importar MP3/WAV, escolher L/R e aprender uma nota MIDI.",13f))
  root.addView(button("CONFIGURAR MIDI / ATUALIZAR DISPOSITIVOS"){setupMidi();Toast.makeText(this,"Dispositivos MIDI atualizados",Toast.LENGTH_SHORT).show()})
 }
 private fun seek(action:(Int)->Unit)=object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){if(u)action(p)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){} }
 private fun setBpm(v:Int){bpm=v.coerceIn(30,300);prefs.edit().putInt("bpm",bpm).apply();if(page==0)bpmText.text="$bpm BPM"}
 private fun nextRoute(s:String)=when(s){"L"->"R";"R"->"L+R";else->"L"}
 private fun configure(i:Int){val choices=arrayOf("Importar MP3/WAV", "Saída: ${routes[i]}", "Aprender MIDI (nota)","Remover áudio")
  AlertDialog.Builder(this).setTitle(names[i]).setItems(choices){_,which->when(which){0->{pendingImport=i;val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="audio/*"};startActivityForResult(intent,100)};1->{routes[i]=nextRoute(routes[i]?:"L");prefs.edit().putString("route$i",routes[i]).apply();configure(i)};2->{midiLearn=i;Toast.makeText(this,"Pressione uma tecla/pad no controlador MIDI",Toast.LENGTH_LONG).show()};3->{stopPad(i);uris.remove(i);prefs.edit().remove("uri$i").apply();showPads()}}}.show()
 }
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==100&&resultCode==RESULT_OK&&pendingImport>=0){val u=data?.data?:return;try{contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){};uris[pendingImport]=u;prefs.edit().putString("uri$pendingImport",u.toString()).apply();showPads()}}
 private fun togglePad(i:Int){if(players.containsKey(i)){stopPad(i);return};val u=uris[i]?:run{configure(i);return};try{
  val p=MediaPlayer();p.setDataSource(this,u);p.isLooping=i<12;p.prepare();val route=routes[i]?:"L";val l=if(route=="R")0f else 1f;val r=if(route=="L")0f else 1f;p.setVolume(if(fadeMs>0)0f else l,if(fadeMs>0)0f else r)
  p.setOnCompletionListener { if(players[i]===p){players.remove(i);effects.remove(i)?.release();p.release();runOnUiThread{refreshPad(i)}} }
  players[i]=p;p.start();try{effects[i]=android.media.audiofx.Equalizer(0,p.audioSessionId).apply{enabled=true}}catch(_:Exception){};applyCutoff()
  if(fadeMs>0)fade(p,0f,1f,fadeMs,l,r){ };refreshPad(i)
 }catch(e:Exception){Toast.makeText(this,"Erro ao abrir áudio: ${e.message}",Toast.LENGTH_LONG).show()}}
 private fun refreshPad(i:Int){buttons[i]?.text=names[i]+if(players.containsKey(i))" ■" else if(uris.containsKey(i))" ●" else " +"}
 private fun fade(p:MediaPlayer,from:Float,to:Float,duration:Int,l:Float,r:Float,done:()->Unit){val start=SystemClock.uptimeMillis();fun step(){if(!p.isPlaying && to>0)return;val t=((SystemClock.uptimeMillis()-start).toFloat()/duration.coerceAtLeast(1)).coerceIn(0f,1f);val vol=from+(to-from)*t;try{p.setVolume(vol*l,vol*r)}catch(_:Exception){return};if(t<1f)handler.postDelayed({step()},25)else done()};step()}
 private fun stopPad(i:Int){val p=players.remove(i)?:return;val route=routes[i]?:"L";val l=if(route=="R")0f else 1f;val r=if(route=="L")0f else 1f
  fade(p,1f,0f,fadeMs,l,r){try{p.stop();p.release()}catch(_:Exception){};effects.remove(i)?.release()};refreshPad(i)
 }
 private fun applyCutoff(){effects.values.forEach { eq ->try{val bands=eq.numberOfBands.toInt();for(b in 0 until bands){val range=eq.bandLevelRange;val high=range[1];val low=range[0];val factor=if(b<bands/2)1f else cutoff/100f;eq.setBandLevel(b,(low+(high-low)*factor).toInt().toShort())}}catch(_:Exception){} }}
 private fun tick(){if(!running)return;val thisBeat=beat++;if(page==0){led.setTextColor(if(thisBeat%4==0)accent else Color.YELLOW);handler.postDelayed({if(page==0)led.setTextColor(Color.DKGRAY)},90)};if(clickSound)playClick(thisBeat%4==0);handler.postDelayed({if(running)tick()},(60000L/bpm))}
 private fun playClick(strong:Boolean){val sampleRate=22050;val count=if(strong)1800 else 1300;val data=ShortArray(count);val freq=if(strong)1250.0 else 900.0;for(i in data.indices){val env=(1.0-i.toDouble()/count).pow(3);data[i]=(sin(2*PI*freq*i/sampleRate)*env*14000).toInt().toShort()};try{val t=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()).setBufferSizeInBytes(count*4).setTransferMode(AudioTrack.MODE_STATIC).build();val stereo=ShortArray(count*2);for(i in 0 until count){stereo[2*i]=if(clickRoute=="R")0 else data[i];stereo[2*i+1]=if(clickRoute=="L")0 else data[i]};t.write(stereo,0,stereo.size);t.play();handler.postDelayed({t.release()},200)}catch(_:Exception){} }
 private fun setupMidi(){val manager=getSystemService(MIDI_SERVICE) as? MidiManager ?:return;midiManager=manager;outputPorts.forEach{try{it.close()}catch(_:Exception){}};midiDevices.forEach{try{it.close()}catch(_:Exception){}};outputPorts.clear();midiDevices.clear()
  manager.devices.forEach { info -> manager.openDevice(info,{device->if(device!=null){midiDevices.add(device);for(n in 0 until info.outputPortCount){try{val port=device.openOutputPort(n);if(port!=null){outputPorts.add(port);port.connect(object:MidiReceiver(){override fun onSend(msg:ByteArray,offset:Int,count:Int,timestamp:Long){if(count<3)return;val status=msg[offset].toInt() and 0xF0;val note=msg[offset+1].toInt() and 0x7F;val velocity=msg[offset+2].toInt() and 0x7F;if(status==0x90&&velocity>0)runOnUiThread{if(midiLearn>=0){midiNotes[midiLearn]=note;prefs.edit().putInt("midi$midiLearn",note).apply();Toast.makeText(this@MainActivity,"${names[midiLearn]} → MIDI $note",Toast.LENGTH_SHORT).show();midiLearn=-1}else{midiNotes.filterValues{it==note}.keys.forEach{togglePad(it)}}}}})}}catch(_:Exception){}}}},handler) }
 }
 private fun showPiano(){page=2;setup("PIANO • 2 OITAVAS")
  root.addView(text("24 teclas: C4 a B5. Toque para ouvir; permite várias notas ao mesmo tempo.",15f))
  root.addView(text("Instrumento sintetizado localmente (não exige conexão).",13f))
  val piano=PianoView(this)
  root.addView(piano,LinearLayout.LayoutParams(-1,420))
  root.addView(text("Dica: use o tablet na horizontal para teclas maiores.",13f))
 }
 private inner class PianoView(context:Context):View(context){
  private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
  private val blackOffsets=setOf(1,3,6,8,10)
  private val pointers=mutableMapOf<Int,Int>()
  private val active=mutableSetOf<Int>()
  override fun onDraw(canvas:Canvas){super.onDraw(canvas)
   val whiteWidth=width/14f
   var white=0
   for(note in 0 until 24){if(note%12 !in blackOffsets){val x=white*whiteWidth;paint.color=if(note in active) accent else Color.WHITE;canvas.drawRect(x+1,2f,x+whiteWidth-1,height.toFloat()-2,paint);paint.color=Color.DKGRAY;paint.style=Paint.Style.STROKE;paint.strokeWidth=2f;canvas.drawRect(x+1,2f,x+whiteWidth-1,height.toFloat()-2,paint);paint.style=Paint.Style.FILL;white++}}
   white=0
   for(note in 0 until 24){if(note%12 in blackOffsets){val x=(white-0.34f)*whiteWidth;paint.color=if(note in active) accent else Color.rgb(25,30,42);canvas.drawRoundRect(x,0f,x+whiteWidth*.68f,height*.60f,5f,5f,paint)}else white++}
   paint.color=Color.GRAY;paint.textSize=22f
   canvas.drawText("C4",whiteWidth*.2f,height-20f,paint);canvas.drawText("C5",whiteWidth*7.2f,height-20f,paint)
  }
  private fun hit(x:Float,y:Float):Int{
   val ww=width/14f
   if(y<height*.60f){var white=0;for(note in 0 until 24){if(note%12 in blackOffsets){val left=(white-.34f)*ww;if(x>=left&&x<left+ww*.68f)return note}else white++}}
   val wi=(x/ww).toInt().coerceIn(0,13);var white=0;for(note in 0 until 24){if(note%12 !in blackOffsets){if(white==wi)return note;white++}};return 0
  }
  override fun onTouchEvent(event:android.view.MotionEvent):Boolean{
   when(event.actionMasked){
    MotionEvent.ACTION_DOWN,MotionEvent.ACTION_POINTER_DOWN->{val ix=event.actionIndex;val id=event.getPointerId(ix);val note=hit(event.getX(ix),event.getY(ix));pointers[id]=note;startPianoNote(note)}
    MotionEvent.ACTION_MOVE->{for(ix in 0 until event.pointerCount){val id=event.getPointerId(ix);val note=hit(event.getX(ix),event.getY(ix));val old=pointers[id];if(old!=note){if(old!=null)stopPianoNote(old);pointers[id]=note;startPianoNote(note)}}}
    MotionEvent.ACTION_UP,MotionEvent.ACTION_POINTER_UP->{val id=event.getPointerId(event.actionIndex);pointers.remove(id)?.let{stopPianoNote(it)}}
    MotionEvent.ACTION_CANCEL->{pointers.values.toList().forEach{stopPianoNote(it)};pointers.clear()}
   };active.clear();active.addAll(pointers.values);invalidate();return true
  }
 }
 private fun startPianoNote(note:Int){if(pianoVoices.containsKey(note))return
  val rate=22050;val freq=440.0*2.0.pow((pianoBaseNote+note-69)/12.0);val samples=ShortArray(2048)
  for(i in samples.indices){val t=i.toDouble()/rate;val wave=sin(2*PI*freq*t)*.72+sin(4*PI*freq*t)*.18+sin(6*PI*freq*t)*.10;samples[i]=(wave*8500).toInt().toShort()}
  try{val track=AudioTrack(AudioManager.STREAM_MUSIC,rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT,samples.size*2,AudioTrack.MODE_STATIC)
   track.write(samples,0,samples.size);track.setLoopPoints(0,samples.size,-1);pianoVoices[note]=track;track.play()
  }catch(_:Exception){}
 }
 private fun stopPianoNote(note:Int){pianoVoices.remove(note)?.let{try{it.stop();it.release()}catch(_:Exception){}}}
 private fun showNotes(){page=1;setup("NOTES • REPERTÓRIOS");val repo=EditText(this).apply{hint="Nome do repertório";setText(prefs.getString("currentRepo","Meu repertório"));setSingleLine(true)};root.addView(repo)
  val song=EditText(this).apply{hint="Título da música";setSingleLine(true)};root.addView(song)
  val notes=EditText(this).apply{hint="Letras, cifras, notas, tom, BPM...";minLines=8;gravity=Gravity.TOP};root.addView(notes)
  root.addView(button("SALVAR MÚSICA"){val r=repo.text.toString().trim();val s=song.text.toString().trim();if(r.isEmpty()||s.isEmpty()){Toast.makeText(this,"Informe repertório e música",Toast.LENGTH_SHORT).show();return@button};prefs.edit().putString("currentRepo",r).putString("song:$r:$s",notes.text.toString()).apply();Toast.makeText(this,"Música salva",Toast.LENGTH_SHORT).show();showNotes()})
  section("MÚSICAS SALVAS • toque para editar")
  val entries=prefs.all.keys.filter{it.startsWith("song:")}.sorted();entries.forEach{key->val rest=key.removePrefix("song:");val r=rest.substringBefore(":");val s=rest.substringAfter(":");root.addView(button("$r  /  $s"){repo.setText(r);song.setText(s);notes.setText(prefs.getString(key,""))})}
  root.addView(button("EXCLUIR MÚSICA EM EDIÇÃO"){val key="song:${repo.text}:${song.text}";AlertDialog.Builder(this).setMessage("Excluir ${song.text}?").setPositiveButton("Excluir"){_,_->prefs.edit().remove(key).apply();showNotes()}.setNegativeButton("Cancelar",null).show()})
 }
 override fun onDestroy(){pianoVoices.keys.toList().forEach{stopPianoNote(it)};running=false;players.keys.toList().forEach{stopPad(it)};outputPorts.forEach{it.close()};midiDevices.forEach{it.close()};super.onDestroy()}
}
