# StagePads — Android

Aplicativo Android nativo (Kotlin), inspirado no fluxo de trabalho de pads musicais, sem usar código ou identidade visual de terceiros.

## Gerar APK no GitHub
1. Crie um repositório novo no GitHub.
2. Envie **o conteúdo desta pasta** para a raiz do repositório (incluindo `.github/workflows/android.yml`).
3. Abra **Actions → Build Android APK → Run workflow** (ou faça push para `main`).
4. Após a execução, baixe o artefato `StagePads-debug-apk`, descompacte e instale o APK no Android.

O GitHub Actions instala Java 17, Android SDK e Gradle 8.9 automaticamente. O APK de debug é instalável para testes (pode ser necessário autorizar instalação de apps de fontes externas).

## Como usar
- Toque em um pad sem som ou segure qualquer pad para importar MP3/WAV.
- Segure o pad para definir saída L, R ou L+R e iniciar o aprendizado de nota MIDI.
- Pads de tons (12) tocam em loop; os 8 drum pads disparam uma vez.
- Click visual continua mesmo com o áudio desligado. BPM via Tap, +/− ou campo manual.
- Cutoff é uma aproximação com equalizador do Android (não um filtro passa-baixas dedicado). Crossfade implementa fade-in/fade-out por pad; não é um crossfade entre dois pads sincronizados.
- Em NOTES, escreva e salve músicas por repertório; dados ficam no dispositivo.

## Limitações desta primeira versão
- Mapeamento MIDI disponível para **acionamento de pads por Note On** em controladores USB/Bluetooth MIDI reconhecidos pelo Android. Ainda não há MIDI Learn de sliders, botões do metrônomo ou mensagens CC.
- Áudio L/R é roteado em estéreo pelo Android; a separação física depende da interface de áudio conectada.
- O click usa agendamento na thread principal e não é um motor de áudio de baixa latência: para shows, recomenda-se evoluir para Oboe/AAudio e testar a sincronização.
- Alterar o BPM enquanto o click toca altera os próximos intervalos, sem quantização dos loops.
- Sem sincronização de repertórios na nuvem e sem exportação de setlists nesta versão.


## Tela 3 — Piano
Teclado virtual de duas oitavas (C4–B5), 24 notas cromáticas, com multitouch e síntese de áudio offline.

## Upload ZIP diretamente no GitHub
O GitHub não extrai automaticamente ZIPs enviados como arquivo. Se você subir apenas `StagePads-GitHub.zip`, o workflow interno não será detectado. Para compilar sem descompactar no seu dispositivo, envie o ZIP para a raiz do repositório e crie manualmente `.github/workflows/build-from-zip.yml` com o conteúdo do arquivo `GITHUB-WORKFLOW-PARA-ZIP.yml` que acompanha o download. O workflow extrai o ZIP no runner e compila o APK.
